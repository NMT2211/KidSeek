import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";

export default function SubjectDetail() {
  const { subjectId } = useParams();
  const [questions, setQuestions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [answers, setAnswers] = useState({});
  const [chatResultId, setChatResultId] = useState(null);
  const [gradingResult, setGradingResult] = useState(null);
  const [submitted, setSubmitted] = useState(false);
  const [waitingForGrading, setWaitingForGrading] = useState(false);

  useEffect(() => {
    const subject = JSON.parse(localStorage.getItem("selectedSubject"));
    const user = JSON.parse(localStorage.getItem("user"));

    if (subject && user) {
      generateQuestions(user, subject);
    } else {
      setError("Không tìm thấy thông tin học sinh hoặc môn học.");
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    let interval;
    if (submitted && chatResultId && waitingForGrading) {
      interval = setInterval(checkGradingStatus, 3000);
    }
    return () => clearInterval(interval);
  }, [submitted, chatResultId, waitingForGrading]);

  const checkGradingStatus = async () => {
    try {
      const res = await axios.get(`http://localhost:5069/api/Chat/feedback/${chatResultId}`);
      if (res.data.status === "done") {
        setGradingResult(res.data);
        setWaitingForGrading(false);
      }
    } catch (err) {
      console.error("Lỗi khi kiểm tra chấm điểm:", err);
    }
  };

  const generateQuestions = async (user, subject) => {
    try {
      const grade = subject.grade || user.grade || "";
      const prompt = `Chỉ trả về JSON. Không ghi chú, không giải thích.

Tạo 10 câu hỏi luyện tập phù hợp với học sinh tên ${user.fullname}, học lớp ${grade}, về môn ${subject.name}.

Mỗi câu gồm:
- question: nội dung câu hỏi
- options: 4 lựa chọn A, B, C, D
- answer: đáp án đúng

Trả về theo định dạng sau:
{
  "questions": [
    {
      "question": "...",
      "options": { "A": "...", "B": "...", "C": "...", "D": "..." },
      "answer": "A"
    }
  ]
}`;

      const res = await axios.post(
        "https://api.deepseek.com/v1/chat/completions",
        {
          model: "deepseek-chat",
          messages: [{ role: "user", content: prompt }],
        },
        {
          headers: {
            Authorization: `Bearer sk-91900a98dd7e494db9054b8a3b8209cb`,
            "Content-Type": "application/json",
          },
        }
      );

      let raw = res.data.choices[0].message.content.trim();
      if (raw.startsWith("```json")) {
        raw = raw.replace(/```json|```/g, "").trim();
      }

      const parsed = JSON.parse(raw);
      if (!parsed.questions || !Array.isArray(parsed.questions)) {
        setError("Dữ liệu AI không chứa danh sách câu hỏi hợp lệ.");
        return;
      }

      setQuestions(parsed.questions);

      const saveRes = await axios.post("http://localhost:5069/api/Chat/save-result", {
        userId: user.userId,
        subjectId: parseInt(subject.subjectId),
        prompt: prompt,
        aiResponse: raw,
      });

      setChatResultId(saveRes.data.chatResultId);
    } catch (err) {
      console.error("Lỗi tạo câu hỏi:", err);
      setError("Không tạo được câu hỏi. Hãy thử lại sau.");
    } finally {
      setLoading(false);
    }
  };

  const handleAnswer = (index, choice) => {
    if (submitted) return;
    setAnswers({ ...answers, [index]: choice });
  };

  const handleSubmit = async () => {
    if (Object.keys(answers).length !== questions.length) {
      alert("Bạn cần trả lời hết tất cả câu hỏi trước khi nộp.");
      return;
    }

    try {
      const payload = {
        chatResultId,
        answers: questions.map((q, i) => ({
          question: q.question || q.content || "Không có câu hỏi",
          studentAnswer: answers[i],
        })),
      };

      await axios.post("http://localhost:5069/api/Chat/submit-answers", payload);
      setSubmitted(true);
      setWaitingForGrading(true);
      alert("Bài đã nộp. Đang chấm điểm...");
    } catch (err) {
      console.error("Lỗi khi nộp bài:", err);
      alert("Gửi bài thất bại.");
    }
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h2 className="text-2xl font-bold mb-4">Câu hỏi luyện tập</h2>

      {loading && (
        <div className="flex items-center gap-2 text-blue-600 text-sm">
          <svg className="animate-spin w-5 h-5 text-blue-600" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
          </svg>
          <span>AI đang tạo câu hỏi...</span>
        </div>
      )}

      {error && <p className="text-red-600">{error}</p>}

      {!loading && !error && questions.length > 0 && (
        <div className="space-y-6">
          {questions.map((q, index) => {
            const selected = answers[index];
            const correctAnswer = gradingResult?.details?.[index]?.correctAnswer;
            const entries = Object.entries(q.choices || q.options || {});

            return (
              <div key={index} className="border p-4 rounded shadow-sm">
                <p className="font-semibold mb-2">
                  {index + 1}. {q.question || q.content || "Không có câu hỏi"}
                </p>
                <div className="grid grid-cols-2 gap-2">
                  {entries.map(([key, text]) => {
                    const isSelected = selected === key;
                    const isCorrect = correctAnswer === key;
                    const isWrong = gradingResult && isSelected && !isCorrect;

                    const baseStyle = "px-3 py-2 rounded border text-left";
                    const selectedStyle = isSelected ? "font-semibold" : "";
                    const correctStyle = gradingResult
                      ? isCorrect
                        ? "bg-green-100 border-green-500 text-green-700"
                        : isWrong
                        ? "bg-red-100 border-red-500 text-red-700"
                        : ""
                      : isSelected
                      ? "bg-blue-100 border-blue-500 text-blue-600"
                      : "hover:bg-blue-50";

                    return (
                      <div
                        key={key}
                        onClick={() => handleAnswer(index, key)}
                        className={`${baseStyle} ${correctStyle} ${selectedStyle} cursor-pointer`}
                      >
                        <span className="font-bold mr-2">{key}.</span> {text}
                        {isSelected && !gradingResult && <span className="ml-2 text-blue-500">(Đã chọn)</span>}
                        {gradingResult && isSelected && <span className="ml-2 italic">(Bạn chọn)</span>}
                        {gradingResult && isCorrect && <span className="ml-2 text-green-700 font-semibold">✔ Đáp án đúng</span>}
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}

          {!submitted && (
            <button
              onClick={handleSubmit}
              className="mt-6 w-full bg-green-600 text-white py-2 rounded hover:bg-green-700 transition"
            >
              Nộp bài và chấm điểm
            </button>
          )}

          {submitted && waitingForGrading && (
            <p className="mt-4 text-blue-600 italic">Đang chấm điểm, vui lòng đợi...</p>
          )}
        </div>
      )}

      {gradingResult && gradingResult.details && (
        <div className="mt-8 p-4 border rounded bg-white shadow">
          <h3 className="text-xl font-semibold text-green-600 mb-4">
            Kết quả: {gradingResult.summary}
          </h3>
          <div className="space-y-4">
            {gradingResult.details.map((item, index) => (
              <div
                key={index}
                className={`p-3 border rounded ${
                  item.isCorrect ? "border-green-400 bg-green-50" : "border-red-400 bg-red-50"
                }`}
              >
                <p className="font-semibold">{index + 1}. {item.question}</p>
                <p>Học sinh trả lời: <strong>{item.studentAnswer}</strong></p>
                <p>Đáp án đúng: <strong>{item.correctAnswer}</strong></p>
                <p className="italic text-sm text-gray-600">Giải thích: {item.explanation}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}