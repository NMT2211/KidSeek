import { useState, useRef, useEffect } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import "../styles/Navbar.css"; // Import your CSS file for styling

export default function Navbar() {
  const user = JSON.parse(localStorage.getItem("user"));
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef();
  const navigate = useNavigate();

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setDropdownOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <nav className="flex items-center justify-between px-20 py-4 bg-white shadow z-50">
      {/* Logo */}
      <NavLink to="/">
        <div className="flex items-center space-x-2">
          
          <img src="/logo.svg" alt="Logo" className="w-8 h-8 rounded-full" />
          <span className="text-2xl font-bold text-blue-600">KidSeek</span>
        </div>
      </NavLink>
      
      {/* Menu */}
      <ul className="flex items-center space-x-4">
        <li>
          <NavLink
            to="/"
            className={({ isActive }) =>
              isActive ? "nav-item nav-item-active" : "nav-item"
            }
          >
            <i className="bi bi-house-door me-1 text-lg"></i>
            Trang chủ
          </NavLink>
        </li>
        <li>
          <NavLink
            to="/about"
            className={({ isActive }) =>
              isActive ? "nav-item nav-item-active" : "nav-item"
            }
          >
            <i className="bi bi-info-circle me-1 text-lg"></i>
            Giới thiệu
          </NavLink>
        </li>
        {user && (
          <>
            <li>
              <NavLink
                to="/Subjects"
                className={({ isActive }) =>
                  isActive ? "nav-item nav-item-active" : "nav-item"
                }
              >
                <i className="bi bi-book me-1 text-lg"></i>
                Môn học
              </NavLink>
            </li>
            <li>
              <NavLink
                to="/ai"
                className={({ isActive }) =>
                  isActive ? "nav-item nav-item-active" : "nav-item"
                }
              >
                <i className="bi bi-chat-dots me-1 text-lg"></i>
                Trò chuyện với AI
              </NavLink>
            </li>
            <li>
              <NavLink
                to="/bai-tap"
                className={({ isActive }) =>
                  isActive ? "nav-item nav-item-active" : "nav-item"
                }
              >
                <i className="bi bi-journal-text me-1 text-lg"></i>
                Bài tập
              </NavLink>
            </li>
            <li>
              <NavLink
                to="/luyen-tap"
                className={({ isActive }) =>
                  isActive ? "nav-item nav-item-active" : "nav-item"
                }
              >
                <i className="bi bi-graph-down me-1 text-lg"></i>
                Luyện tập
              </NavLink>
            </li>
            <li>
              <NavLink
                to="/nang-cap"
                className={({ isActive }) =>
                  isActive ? "nav-item nav-item-active" : "nav-item"
                }
              >
                <i className="bi bi-star me-1 text-lg"></i>
                Nâng cấp
              </NavLink>
            </li>
          </>
        )}
      </ul>

      {/* User dropdown */}
      {user ? (
        <div className="relative" ref={dropdownRef}>
          <button
            onClick={() => setDropdownOpen(!dropdownOpen)}
            className="user-button"
          >
            <i className="bi bi-person-circle text-lg"></i>
            <span className="capitalize">{user.fullname}</span>
            <i className="bi bi-caret-down text-xs"></i>
          </button>

          {dropdownOpen && (
            <div className="dropdown-menu">
              <button
                onClick={() => {
                  navigate("/profile");
                  setDropdownOpen(false);
                }}
                className="dropdown-item"
              >
                <i className="bi bi-person"></i>
                Hồ sơ của tôi
              </button>
              <hr className="border-gray-200 my-1" />
              <button
                onClick={() => {
                  localStorage.removeItem("user");
                  navigate("/login");
                }}
                className="dropdown-item"
              >
                <i className="bi bi-box-arrow-right"></i>
                Đăng xuất
              </button>
            </div>
          )}
        </div>
      ) : (
        <div className="flex items-center gap-3">
          <NavLink
            to="/login"
            className="text-base font-medium text-gray-700 hover:text-blue-600"
          >
            <i className="bi bi-box-arrow-in-right text-lg"></i> Đăng nhập
          </NavLink>

          <NavLink
            to="/register"
            className="group relative flex items-center gap-2 bg-blue-500 text-white text-base font-medium px-4 py-2 rounded-full overflow-hidden transition"
          >
            <i className="bi bi-person-plus text-lg z-10"></i>
            <span className="z-10">Đăng ký</span>
            <span className="absolute inset-0 bg-blue-400 opacity-30 translate-x-[-100%] group-hover:translate-x-0 transition-transform duration-500 ease-out"></span>
          </NavLink>
        </div>
      )}
    </nav>
  );
}
