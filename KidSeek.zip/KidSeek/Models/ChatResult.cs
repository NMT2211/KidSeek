using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace KidSeek.Api.Models
{
    
    public class ChatResult
    {
        public int ChatResultId { get; set; }

        public int UserId { get; set; }

        public int SubjectId { get; set; }

        public string Prompt { get; set; }

        public string AiResponse { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.Now;

        [JsonIgnore]
        public User? User { get; set; }             // ✅ nullable

        [JsonIgnore]
        public Subject? Subject { get; set; }       // ✅ nullable

        [JsonIgnore]
        public ICollection<ChatAnswer>? Answers { get; set; } // ✅ nullable
    }


}
