using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace KidSeek.Api.Models
{
    public class ChatAnswer
    {
        [Key]
        public int AnswerId { get; set; }                         // Mã dòng trả lời

        [ForeignKey("ChatResult")]
        public int ChatResultId { get; set; }                     // Phiên chat tương ứng

        public string Question { get; set; }                      // Câu hỏi AI đưa ra
        public string StudentAnswer { get; set; }                 // Câu trả lời học sinh nhập
        public string AiFeedback { get; set; }                    // Phản hồi AI (nếu có)

        public ChatResult ChatResult { get; set; }
    }
}
