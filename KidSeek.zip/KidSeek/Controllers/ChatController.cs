using Microsoft.AspNetCore.Mvc;
using KidSeek.Api.Data;
using KidSeek.Api.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Text.Json;


namespace KidSeek.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ChatController : ControllerBase
    {
        private readonly KidSeekDbContext _context;

        public ChatController(KidSeekDbContext context)
        {
            _context = context;
        }

        // POST: api/chat/save-result
        [HttpPost("save-result")]
        public IActionResult SaveChatResult([FromBody] ChatResult result)
        {
            if (!_context.Users.Any(u => u.UserId == result.UserId))
                return NotFound(new { message = "Không tìm thấy người dùng." });

            result.CreatedAt = DateTime.Now;
            _context.ChatResults.Add(result);
            _context.SaveChanges();

            return Ok(new { message = "Lưu kết quả thành công", result.ChatResultId });
        }
        private async Task<string> CallAiFeedbackForGrading(List<ChatAnswer> answers)
        {
            var formatted = answers.Select((ans, index) =>
                $"{index + 1}. Câu hỏi: {ans.Question}\nHọc sinh trả lời: {ans.StudentAnswer}").ToList();

            string prompt = $@"
        Hãy chấm điểm các câu sau theo thang điểm 10. Trả về dưới dạng JSON theo cấu trúc:
        {{
        ""score"": 8,
        ""results"": [
            {{
            ""question"": ""..."",
            ""studentAnswer"": ""..."",
            ""correctAnswer"": ""..."",
            ""isCorrect"": true,
            ""explanation"": ""...""
            }}
        ]
        }}

        Các câu:
        {string.Join("\n\n", formatted)}";

            using var http = new HttpClient();
            http.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", "sk-91900a98dd7e494db9054b8a3b8209cb");

            var body = new
            {
                model = "deepseek-chat",
                messages = new[] {
                    new { role = "user", content = prompt }
                }
            };

            var response = await http.PostAsJsonAsync("https://api.deepseek.com/v1/chat/completions", body);
            var json = await response.Content.ReadAsStringAsync();

            // Cắt bỏ phần mã markdown nếu có
            int start = json.IndexOf("```json");
            int end = json.LastIndexOf("```");
            string pureJson = (start >= 0 && end > start) ? json.Substring(start + 7, end - (start + 7)).Trim() : json;

            return pureJson;
        }

        // POST: api/chat/save-answer
        [HttpPost("submit-answers")]
        public async Task<IActionResult> SubmitAnswers([FromBody] JsonElement body)
        {
            if (!body.TryGetProperty("chatResultId", out var chatResultIdElement) ||
                !body.TryGetProperty("answers", out var answersElement))
            {
                return BadRequest("Thiếu dữ liệu gửi lên.");
            }

            int chatResultId = chatResultIdElement.GetInt32();
            var result = _context.ChatResults.FirstOrDefault(r => r.ChatResultId == chatResultId);
            if (result == null)
                return NotFound(new { message = "Không tìm thấy phiên chat." });

            var parsedAnswers = answersElement.Deserialize<List<ChatAnswer>>();
            foreach (var ans in parsedAnswers)
            {
                ans.ChatResultId = chatResultId;
                ans.AiFeedback = "Đang chấm..."; // gắn tạm
                _context.ChatAnswers.Add(ans);
            }

            await _context.SaveChangesAsync();

            // 🔁 Chạy chấm điểm ngầm
            _ = Task.Run(async () =>
            {
                try
                {
                    var feedbackJson = await CallAiFeedbackForGrading(parsedAnswers);
                    using var doc = JsonDocument.Parse(feedbackJson);
                    var root = doc.RootElement;
                    var results = root.GetProperty("results");

                    for (int i = 0; i < parsedAnswers.Count; i++)
                    {
                        var existing = _context.ChatAnswers.FirstOrDefault(x =>
                            x.ChatResultId == chatResultId && x.Question == parsedAnswers[i].Question);

                        if (existing != null)
                            existing.AiFeedback = results[i].ToString();
                    }

                    await _context.SaveChangesAsync();
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Lỗi khi chấm điểm ngầm: " + ex.Message);
                }
            });

            // ✅ Trả về ngay
            return Ok(new { message = "Đã lưu bài thành công. Kết quả sẽ được cập nhật sau." });
        }



        // GET: api/chat/by-user/1
        [HttpGet("by-user/{userId}")]
        public IActionResult GetChatsByUser(int userId)
        {
            var results = _context.ChatResults
                .Where(r => r.UserId == userId)
                .OrderByDescending(r => r.CreatedAt)
                .ToList();

            return Ok(results);
        }

        // GET: api/chat/feedback/{chatResultId}
        [HttpGet("feedback/{chatResultId}")]
        public IActionResult GetFeedbackResult(int chatResultId)
        {
            var answers = _context.ChatAnswers
                .Where(a => a.ChatResultId == chatResultId)
                .ToList();

            if (answers.Any(a => a.AiFeedback == null || a.AiFeedback.Contains("Đang chấm")))
            {
                return Ok(new { status = "pending" });
            }

            var details = answers.Select(a =>
            {
                var feedback = JsonDocument.Parse(a.AiFeedback).RootElement;
                return feedback;
            }).ToList();

            double score = details.Count(d => d.GetProperty("isCorrect").GetBoolean()) / (double)details.Count * 10;

            return Ok(new
            {
                status = "done",
                summary = $"Bạn đạt {Math.Round(score, 1)}/10 điểm",
                details
            });
        }

    }
}
